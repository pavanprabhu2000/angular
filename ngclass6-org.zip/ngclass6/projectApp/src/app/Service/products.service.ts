import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http:HttpClient) { }

  getData() {
    return this.http.get("https://ty-shop.herokuapp.com/api/products");
  }
  addData(product:any){
    return this.http.post("https://ty-shop.herokuapp.com/api/products",product)

  }

  updateData(_id:any,product:any){
    return this.http.put(`https://ty-shop.herokuapp.com/api/products/${_id}`,product)

  }

  // deleting the product by using the http method

  deleteData(_id:any){
    return this.http.delete(`https://ty-shop.herokuapp.com/api/products/${_id}`);
  }

  getDataproduct() {
    return this.http.get("http://localhost:8080");
  }
}
